const myCarouselElement = document.querySelector('#cynthia_Carousel')

const carousel = new bootstrap.Carousel(myCarouselElement, {
  interval: 5000,
  touch: false
})